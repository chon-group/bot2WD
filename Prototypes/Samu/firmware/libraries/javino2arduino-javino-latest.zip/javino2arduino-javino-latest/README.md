# javino - Javino (http://javino.sf.net)

## DESCRIPTION
A library to supports a robotic-agent platform that uses Raspberry+Arduino boards and Jason Framework.

## COPYRIGHT
N. M. Lazarin e C. E. Pantoja, “A robotic-agent platform for embedding software agents using raspberry pi and arduino boards”, in __Proceedings of 9th Software Agents, Environments and Applications School (WESAAC 2015)__, Niteroi: UFF, 2015, p. 13–20. [Online]. Full-paper Available at: [ResearchGate](https://www.researchgate.net/publication/277403727_A_Robotic-agent_Platform_for_Embedding_Software_Agents_Using_Raspberry_Pi_and_Arduino_Boards)

